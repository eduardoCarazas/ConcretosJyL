package com.integrador.ProyectoConcretos.Modelo.DAO;

import com.integrador.ProyectoConcretos.Modelo.Entidades.Producto;

import java.util.List;

public interface IProductoDAO {
    public List<Producto> getProductos();
}
