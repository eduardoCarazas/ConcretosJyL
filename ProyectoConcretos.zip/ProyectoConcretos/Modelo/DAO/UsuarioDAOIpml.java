package com.integrador.ProyectoConcretos.Modelo.DAO;

import com.integrador.ProyectoConcretos.Modelo.Entidades.Usuario;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class UsuarioDAOIpml implements IUsuarioDAO{

    @PersistenceContext
    EntityManager entityManager;

    @Override
    public List<Usuario> getUsuarios() {
        String query = "FROM Usuario";
        return entityManager.createQuery(query).getResultList();
    }

    @Override
    @Transactional
    public void registrar(Usuario usuario) {
        entityManager.persist(usuario);
    }

    @Override
    public Usuario obtenerUsuarioPorCredenciales(Usuario usuario) {
        String query = "FROM Usuario WHERE nombre = :nombre AND password = :password";
        List<Usuario> lista = entityManager.createQuery(query)
                .setParameter("nombre", usuario.getNombre())
                .setParameter("password", usuario.getPassword())
                .getResultList();
        if (lista.size() > 0) {
            return lista.get(0);
        }else{
            return null;
        }
    }
}
