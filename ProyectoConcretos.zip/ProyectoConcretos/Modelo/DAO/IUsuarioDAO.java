package com.integrador.ProyectoConcretos.Modelo.DAO;

import com.integrador.ProyectoConcretos.Modelo.Entidades.Usuario;

import java.util.List;

public interface IUsuarioDAO{

    List<Usuario> getUsuarios();

    void registrar(Usuario usuario);

    Usuario obtenerUsuarioPorCredenciales(Usuario usuario);
}
