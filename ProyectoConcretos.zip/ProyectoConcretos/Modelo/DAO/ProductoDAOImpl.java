package com.integrador.ProyectoConcretos.Modelo.DAO;

import com.integrador.ProyectoConcretos.Modelo.Entidades.Producto;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class ProductoDAOImpl implements IProductoDAO{

    @PersistenceContext
    EntityManager entityManager;

    @Override
    public List<Producto> getProductos() {
        String query = "FROM Producto";
        return entityManager.createQuery(query).getResultList();    }
}
