package com.integrador.ProyectoConcretos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoConcretosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoConcretosApplication.class, args);
	}

}
