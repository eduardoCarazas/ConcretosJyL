package com.integrador.ProyectoConcretos.Controlador;

import com.integrador.ProyectoConcretos.Modelo.DAO.IUsuarioDAO;
import com.integrador.ProyectoConcretos.Modelo.Entidades.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UsuarioController {

    @Autowired
    private IUsuarioDAO iusuarioDAO;

    @GetMapping
    public List<Usuario> getUsuarios(){
        return iusuarioDAO.getUsuarios();
    }


    //@RequestMapping(method = RequestMethod.POST)
   @PostMapping
    public boolean registrarUsuario(@RequestBody Usuario usuario){
       try{
           iusuarioDAO.registrar(usuario);
           return true;
       }catch(Exception ex){

       }
       return false;
    }

    @PostMapping("/login")
    public Usuario login(@RequestBody Usuario usuario){
        Usuario logeado = null;
        logeado = iusuarioDAO.obtenerUsuarioPorCredenciales(usuario);
        return logeado;
    }
}
