package com.integrador.ProyectoConcretos.Controlador;

import com.integrador.ProyectoConcretos.Modelo.DAO.IProductoDAO;
import com.integrador.ProyectoConcretos.Modelo.Entidades.Producto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/productos")
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class ProductoController {

    @Autowired
    private IProductoDAO productoDAO;

    @GetMapping
    public List<Producto> getProductos(){
        return productoDAO.getProductos();
    }
}
