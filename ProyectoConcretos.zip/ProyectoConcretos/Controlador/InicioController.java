package com.integrador.ProyectoConcretos.Controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.data.repository.query.Param;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class InicioController {

    @Autowired
    private JavaMailSender mailSender;

    @Transactional
    @GetMapping("/email")

    public boolean EnviarCorreo(@Param("correo") String correo) {
        boolean estado = false;

        try {
            String ruta = ".//src//main//resources//static//Imagenes//";
            String nomImagen = "imgEmail.jpeg";
            MimeMessage message = mailSender.createMimeMessage();

            MimeMessageHelper helper = new MimeMessageHelper(message,
                    MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED);

            File file = new File(ruta + nomImagen);
            FileSystemResource fileResource = new FileSystemResource(file);

            String html = "Pureeba contenido";

            helper.setTo(correo);
            helper.setText(html, false);
            helper.setSubject("Bienvenidos!");
            helper.addAttachment(nomImagen, fileResource);
            mailSender.send(message);

            estado = true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return estado;
    }

}
